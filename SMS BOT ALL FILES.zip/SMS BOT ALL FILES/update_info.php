<?php 

$password = $_POST['password'];

$senderNum = $_POST['senderNum'];
$message = $_POST['message'];
$smsTime = $_POST['smsTime'];

if($password == '1234567890' ){
	
//connect
$con = mysqli_connect('localhost', 'db_user', 'db_password', 'database_name');

$sql = "INSERT INTO sms (senderNum, message, smsTime) VALUES ('$senderNum', '$message', '$smsTime');";
$result = mysqli_query($con, $sql);


echo "SMS was sent to server!!";



///############################################################

	
	
	   

	   
//CLOSE CONNECTION
mysqli_close($con);

}




?>