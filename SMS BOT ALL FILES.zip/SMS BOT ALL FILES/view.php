<?php 

$key = $_GET['key'];


if (strpos($key, '113355') !== false) {
 

 
//connect
$con = mysqli_connect('localhost', 'db_user', 'db_password', 'database_name');

$sql = "SELECT * FROM sms ORDER BY id DESC ";
$result = mysqli_query($con, $sql);
//$products = array();
$temp = array();

$count=0;
while($row2 = mysqli_fetch_assoc($result)){
	$count++;
	
	     $senderNum = $row2['senderNum'];
	     $message = $row2['message'];
		 $smsTime = $row2['smsTime'];
		 echo 'Sender No: '. $senderNum. '<br>'. $message. '<br>'.$smsTime. '<br><br>';
		 
		 if ($count>10) break;
		   
}



///-------------------------------------------	
	
	
	   

	   
//CLOSE CONNECTION
mysqli_close($con);

}




?>