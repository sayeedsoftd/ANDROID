package com.example.season2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

EditText edbuy,edsell;
Button button2;
TextView tvdisply;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edbuy=findViewById(R.id.edbuy);
        edsell=findViewById(R.id.edsell);
        button2=findViewById(R.id.button2);
        tvdisply=findViewById(R.id.tvdisply);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double buyprice,sellprice,profit,profitpersent;
                buyprice=Double.parseDouble(edbuy.getText().toString());
                sellprice=Double.parseDouble(edsell.getText().toString());
                profit=sellprice-buyprice;
                profitpersent=profit/buyprice*100;
                tvdisply.setText("Show result :\n"+profit+"\n"+profitpersent+"%");


                //koto profit korte chu
               // profit=buyprice+((buyprice*sellprice)/100);
                //tvdisply.setText(""+profit);
            }
        });






    }
}