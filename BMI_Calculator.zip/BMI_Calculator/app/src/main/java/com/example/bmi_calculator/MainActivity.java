package com.example.bmi_calculator;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Button bclick;
    TextView tvdisplay;
    EditText eweight, efoot, einchi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadLanguage();
        setContentView(R.layout.activity_main);

        bclick=findViewById(R.id.bclick);
        tvdisplay=findViewById(R.id.tvdisplay);
        eweight=findViewById(R.id.eweight);
        efoot=findViewById(R.id.efoot);
        einchi=findViewById(R.id.einchi);
        bclick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              String sweight=eweight.getText().toString();
              Double  weight=Double.parseDouble(sweight);

              String sfoot=efoot.getText().toString();
              Double foot=Double.parseDouble(sfoot);
              foot=foot*0.3084;

              String sinchi=einchi.getText().toString();
              Double inchi=Double.parseDouble(sinchi);
              inchi=inchi*0.0254;


              Double myhight=foot+inchi;
              Double myindex=weight/(myhight*myhight);
              tvdisplay.setText("YOUR BMI :"+myindex);

            }
        });





        findViewById(R.id.btchangelanguage).setOnClickListener(view ->{
            showLanguageDialoge();
        });

    }

    private void showLanguageDialoge() {
        final String[] languageList={"English","বাংলা","عربي"};
        SharedPreferences sharedPreferences=getSharedPreferences("language seetings",MODE_PRIVATE);
        int item=sharedPreferences.getInt("item",0);
        AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(getString(R.string.select_language));
        builder.setSingleChoiceItems(languageList, item, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int position) {
                if (position==0){
                    setLanguage("en",0);
                    recreate();
                } else if (position==1) {
                    setLanguage("bn",1);
                    recreate();

                }

                else if (position==2) {
                    setLanguage("ar",2);
                    recreate();

                }
                // noticable point
                dialogInterface.dismiss();

            }


        });
        builder.setNegativeButton("close", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();

    }
     private void setLanguage(String language, int item) {
        Locale locale=new Locale(language);
        Locale.setDefault(locale);
        Configuration configuration=new Configuration();
        configuration.locale=locale;
        getBaseContext().getResources().updateConfiguration(configuration,getBaseContext().getResources().getDisplayMetrics());

        // set language
        SharedPreferences.Editor editor=getSharedPreferences("language seetings",MODE_PRIVATE).edit();
        editor.putString("language",language);
        editor.putInt("item",item);
        editor.apply();


    }// set language end here

    private  void loadLanguage()
    {
        SharedPreferences sharedPreferences=getSharedPreferences("language seetings",MODE_PRIVATE);
        String language =sharedPreferences.getString("language","en");
        int item=sharedPreferences.getInt("item",0);
        setLanguage(language,item);
    }//load language end here

}