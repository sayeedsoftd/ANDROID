package com.example.jakat;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class JakatCalculator2 extends AppCompatActivity {
    EditText eamount,emoney;
    Button bcount;
    TextView tvdisplay;
    EditText esmoney,ermoney,evmoney,enmoney,ebmoney,ejmoney,ebumoney,efmoney,erinmoney;
    Button calculate;
    TextView tvdisplay1,tvdisplay2,show;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jakat_calculator2);

        esmoney=findViewById(R.id.esmoney);
        ermoney=findViewById(R.id.ermoney);
        evmoney=findViewById(R.id.evmoney);
        enmoney=findViewById(R.id.enmoney);
        ebmoney=findViewById(R.id.ebmoney);
        ejmoney=findViewById(R.id.ejmoney);
        ebumoney=findViewById(R.id.ebumoney);
        efmoney=findViewById(R.id.efmoney);
        erinmoney=findViewById(R.id.erinmoney);
        calculate=findViewById(R.id.calculate);
        tvdisplay1=findViewById(R.id.tvdisplay1);
        tvdisplay2=findViewById(R.id.tvdisplay2);
        show=findViewById(R.id.show);



        // ----------------------------
        eamount=findViewById(R.id.eamount);
        emoney=findViewById(R.id.emoney);
        bcount=findViewById(R.id.bcount);
        tvdisplay=findViewById(R.id.tvdisplay);
        bcount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mystring=eamount.getText().toString();
                int mynumber=Integer.parseInt(mystring);
                String mystring1=emoney.getText().toString();
                int mynumber1=Integer.parseInt(mystring1);
                int number=mynumber*mynumber1;
                tvdisplay.setText("টাকার পরিমাণ = "+number+" টাকা");


            }
        });
        // ----------------------------
        calculate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String myString=esmoney.getText().toString();
                int myNumber=Integer.parseInt(myString);
                String myString1=ermoney.getText().toString();
                int myNumber1=Integer.parseInt(myString1);
                String myString2=evmoney.getText().toString();
                int myNumber2=Integer.parseInt(myString2);
                String myString3=enmoney.getText().toString();
                int myNumber3=Integer.parseInt(myString3);
                String myString4=ebmoney.getText().toString();
                int myNumber4=Integer.parseInt(myString4);
                String myString5=ejmoney.getText().toString();
                int myNumber5=Integer.parseInt(myString5);
                String myString6=ebumoney.getText().toString();
                int myNumber6=Integer.parseInt(myString6);
                String myString7=efmoney.getText().toString();
                int myNumber7=Integer.parseInt(myString7);
                String myString8=erinmoney.getText().toString();
                int myNumber8=Integer.parseInt(myString8);
                int result=myNumber+myNumber1+myNumber2+myNumber3+myNumber4+myNumber5+myNumber6+myNumber7-myNumber8;
                tvdisplay1.setText("  = "+result+"  টাকা");

                if (result>84000)
                {
                    tvdisplay2.setText("আপনার উপর যাকাত ফরজ  ");
                    Double result1=(result/100)*2.5;
                    show.setText("="+result1+" টাকা");
                }
                else {
                    tvdisplay2.setText("আপনার উপর যাকাত ফরজ হয়নি");

                }

            }
        });


    }
}