package com.example.news_app;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class News_Description extends AppCompatActivity {
    ImageView coverImg;
    TextView titleVar,titledes;
    FloatingActionButton febButton;
    public static String TITLEVAR="";
    public static String TITLEDES="";
    public static Bitmap MY_BitMap=null;// BitMap use another activity picture  insert another activity
    TextToSpeech textToSpeech;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_description);
        coverImg=findViewById(R.id.coverImg);
        titleVar=findViewById(R.id.titleVar);
        titledes=findViewById(R.id.titledes);
        febButton=findViewById(R.id.febButton);

        titleVar.setText(TITLEVAR);
        titledes.setText(TITLEDES);

        if (MY_BitMap!=null) coverImg.setImageBitmap(MY_BitMap);
        textToSpeech=new TextToSpeech(News_Description.this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int i) {

            }
        });



        febButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tex=titledes.getText().toString();
                textToSpeech.speak(tex,TextToSpeech.QUEUE_FLUSH,null,null);


            }
        });


    }
}