package com.example.current_bill_count;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    EditText edvew;
    Button button;
    TextView tvdisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edvew=findViewById(R.id.edvew);
        button=findViewById(R.id.button);
        tvdisplay=findViewById(R.id.tvdisplay);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mystring=edvew.getText().toString();
                int mynum=Integer.parseInt(mystring);
                if (mynum==0){
                    tvdisplay.setError("Full fill condition");

                }

                else if (mynum<=50)
                {
                    mynum*=0.50;
                    tvdisplay.setText("Electricity Bill=BDT  "+mynum);
                }

                else if (mynum>50||mynum<=150)
                {
                    mynum*=0.75;
                    tvdisplay.setText("Electricity Bill=BDT  "+mynum);
                }
                else if (mynum>150||mynum<=250)
                {
                    mynum*=1.20;
                    tvdisplay.setText("Electricity Bill=BDT  "+mynum);
                }
                else if (mynum>=251)
                {
                    mynum*=(mynum*20/100);
                    tvdisplay.setText("Electricity Bill=BDT  "+mynum);
                }
                else {
                    tvdisplay.setText("show error ");
                }


            }
        });



    }
}